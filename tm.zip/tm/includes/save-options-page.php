<?php

function MAZ_save_options(){

	if(!current_user_can('publish_pages')){
		wp_die('Vous n etes pas autorise');
	}
	check_admin_referer('MAZ_options_verify');

	$opts = get_option('MAZ_opts');


	$opts['legend_01'] = sanitize_text_field($_POST["MAZ_legend_01"]);

	$opts['legend_01_url'] = sanitize_text_field($_POST["MAZ_image_url_01"]);

	update_option('MAZ_opts', $opts);

	wp_redirect(admin_url('admin.php?page=MAZ_theme_opts&status=1'));
	exit;

}