<?php

function MAZ_build_options_page(){

	$theme_opts = get_option('MAZ_opts');
?>
<div class="wrap">
	<div class="container">



<div class="container col-md-12">
		<?php 
		if(isset($_GET['status']) && $_GET['status'] == 1){
			echo '<div class="alert alert-success"> Mise a jour effectuee avec succes </div> ';
		} ?>
</div>


<div class="container">
<div class="jumbotron col-md-8">
	<h1>Nos services</h1>
</div>
<div class="col-md-3 text-center">
	<a href="https://smarktic.com/"><img src="http://smarktic.com/wp-content/uploads/2017/04/Logo-for-website-en.png" alt="Smarktic Agence Digitale"></a>
	<div >
		Communication en Ligne <br>et Marketing Digital
	</div>
</div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="well well-sm">
                <div class="row">


			<form id="form-MAZ-options" class="form-horizontal" method="post" action="admin-post.php">
			<input type="hidden" name="action" value="MAZ_save_options">
			<?php
			//	attribut value = "fonction utilisee pour sauvegarder les options"
			//	add_action('admin_post_MAZ_save_options', 'my-function');
			wp_nonce_field('MAZ_options_verify');?>
<?php $theme_opts = get_option('MAZ_opts'); ?>
<img src="<?php echo $theme_opts['legend_01_url']; ?>" class="img-responsive  center-block" style="width:300px; " alt="" />

                    <div class="col-md-3">
						<img  id="img_preview_01" src="<?php echo $theme_opts['image_01_url']; ?>"
						class="img-responsive img-thumbnail img-rounded" alt-"" >

						<button class="btn btn-primary btn-lg btn-select-img" type="button"
						id="btn_img_01"> choisir image </button>768x449
                    </div>

                    <div class="col-md-9">
                        <h5>URL Image</h5>
                        
                        <div class="form-group">
						
							<div class="col-sm-12">
								<input type="text"  id="MAZ_image_01" name="MAZ_image_01" disabled
								value="<?php echo $theme_opts['image_01_url'];?>" style="width: 100% ;"/>

								<input type="hidden" width="300px" id="MAZ_image_url_01" name="MAZ_image_url_01"
								value="<?php echo $theme_opts['image_01_url'];?>" style="width: 100% ;"/>
							</div>
						</div>
                        <!-- Split button -->
                        <h5>Legende</h5>
							<div class="form-group">
								
								
								<div class="col-sm-12">

<textarea class="form-control" id="MAZ_legend_01" rows="3" name="MAZ_legend_01" value="<?php echo $theme_opts['legend_01'];?>"></textarea>
								</div>
							</div>

							<div>
								<button id="validation" type="submit" class="btn btn-success btn-lg">Mettre a jour</button>
							</div>

						</div>
            </form>



                </div>
            </div>
        </div>

        <div class="col-md-3" >
        <a href="https://smarktic.com/"> <img src="http://rd.smarktic.com/bannierepb.jpg" style="width: 240px; height: 382px;" alt="Smarktic Agence Digitale"></a>
        	
        </div>

    </div>
</div>








	</div>
</div>
<?php


}