<?php

define('MAZ_version', '1.0.0');
define('MAZj_version', '1.1.1');

function MAZ_scripts(){
	
	
	wp_enqueue_style('MAZ_boots', get_template_directory_uri().'/css/bootstrap.min.css', array(), MAZ_version, 'all');
	wp_enqueue_style('MAZ_icone', get_template_directory_uri().'/css/font-awesome/css/font-awesome.min.css', array(), MAZ_version, 'all');
	wp_enqueue_style('MAZ_animat', get_template_directory_uri().'/css/animate.min.css', array(), MAZ_version, 'all');
	wp_enqueue_style('MAZ_carousel', get_template_directory_uri().'/css/owl.carousel.css', array(), MAZ_version, 'all');
	wp_enqueue_style('MAZ_custom', get_template_directory_uri().'/style.css', array('MAZ_boots'), MAZ_version, 'all');
	wp_enqueue_style('MAZ_custom2', get_template_directory_uri().'/css/w3.css', array('MAZ_boots'), MAZ_version, 'all');




	
	wp_enqueue_script('MAZ_smarktic', get_template_directory_uri().'/js/script.js', array('jquery'), MAZj_version, true);
	wp_enqueue_script('MAZ_boots_js', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), MAZj_version, true);
	wp_enqueue_script('MAZ_carousel', get_template_directory_uri().'/js/owl.carousel.min.js', array('jquery'), MAZj_version, true);
	wp_enqueue_script('MAZ_jqeasy', get_template_directory_uri().'/js/jquery.easing.1.3.js', array('jquery'), MAZj_version, true);
	wp_enqueue_script('MAZ_wow', get_template_directory_uri().'/js/wow.min.js', array(), MAZj_version, true);
	

}
add_action('wp_enqueue_scripts','MAZ_scripts');

//**************** Bootstrap pour admin ***********

function MAZ_admin_init(){

		function MAZ_admin_scripts(){

			if(!isset($_GET['page']) AND $_GET['page'] !="MAZ_theme_opts"){
				return;
			}
			
			wp_enqueue_style('MAZ_boots_adm', get_template_directory_uri().'/css/bootstrap.min.css', array(), MAZ_version);

			wp_enqueue_media();
			wp_enqueue_script('MAZ-admin-init', get_template_directory_uri(). '/js/admin-options.js',
				array(),MAZj_version, true);

		}
		add_action('admin_enqueue_scripts','MAZ_admin_scripts');

		include('includes/save-options-page.php');
		add_action('admin_post_MAZ_save_options','MAZ_save_options');

}

add_action('admin_init','MAZ_admin_init');

//***************

function MAZ_activ_options(){

	$theme_opts = get_option('MAZ_opts');
	if(!$theme_opts) {
		$opts = array(
			'image_01_url' => '',
			'legend_01'    => ''
			);
		add_option('MAZ_opts',$opts);
	}
}
add_action('after_switch_theme','MAZ_activ_options');

//**************** Set Up ***********

function MAZ_admin_menus(){
	add_menu_page(
		'Nos SERVICES',
		'TTC SERVICES',
		'publish_pages',
		'MAZ_theme_opts',
		'MAZ_build_options_page'
		);

	include('includes/build-options-page.php');
}
add_action('admin_menu','MAZ_admin_menus');

//**************** Set Up ***********

function MAZ_widgets_init(){
	register_sidebar(array(
		'name'			=> 'A propos de nous - texte',
		'description'	=> 'Widgets affiche: 1',
		'id'			=> 'widgetized-texte',
		'before_widget'	=> '<div id="%1$s" class="col-md-12 %2$s"><div class="inside-widget">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h2 class="h3 text-center">',
		'after_title'	=> '</h2>',
		));
	register_sidebar(array(
		'name'			=> 'A propos de nous - video ',
		'description'	=> 'Widgets affiche: 1 video',
		'id'			=> 'widgetized-footer-video',
		'before_widget'	=> '<div id="%1$s" class="col-md-12 %2$s"><div class="inside-widget">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h2 class="h3 text-center">',
		'after_title'	=> '</h2>',
		));
	register_sidebar(array(
		'name'			=> 'Footer sideBar ',
		'description'	=> 'footer Widgets: 4',
		'id'			=> 'widgetized-footer',
		'before_widget'	=> '<div id="%1$s" class="col-md-3 %2$s"><div class="inside-widget" style="font-size: 14px;">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h2 class="h4 text-left" style="color:#fff;">',
		'after_title'	=> '</h2><div class="separetorwhite"></div>',
		));
	register_sidebar(array(
		'name'			=> 'Gallery 2 sideBar ',
		'description'	=> 'Gallery Widgets: 3',
		'id'			=> 'widgetized-gallery-2',
		'before_widget'	=> '<div id="%1$s" class="col-md-12 %2$s"><div class="inside-widget">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h2 class="h3 text-left"> ',
		'after_title'	=> '</h2>',
		));
	register_sidebar(array(
		'name'			=> 'NewsLetter ',
		'description'	=> 'NewsLetter: 1',
		'id'			=> 'widgetized-newsletters',
		'before_widget'	=> '<div id="%1$s" class="col-md-12 %2$s"><div class="inside-widget">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h2 class="h3 text-left"> ',
		'after_title'	=> '</h2>',
		));
}
add_action('widgets_init','MAZ_widgets_init');


//**************** Set Up ***********
function MAZ_setup(){
	
	add_theme_support( 'custom-logo' );
	add_theme_support('post-thumbnails');
	remove_action('wp_head','wp_generator');
	add_theme_support('title-tag');
	require_once('includes/wp-bootstrap-navwalker.php');
	register_nav_menus(array('primary'=>'Principal', 'secondary'=>'Secondaire'));

}
add_action('after_setup_theme','MAZ_setup');



//**************** Set Up ***********

function MAZ_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'MAZ_excerpt_length', 999 );


//**************** Set Up ***********

function my_images_sizes($sizes){
	$addsizes = array(
		"medium_large" => "Medium Large"
		);
	$newsizes = array_merge($sizes, $addsizes);
	return $newsizes;
}

add_filter('image_size_names_choose','my_images_sizes');

//**************** Set Up ***********

function MAZ_slider_init() {
	$labels = array(
		'name'               => 'Gallerie : ILS ONT RECOURU A NOUS',
		'singular_name'      => 'Image  Accueil',
		'add_new'            => 'Ajouter image',
		'add_new_item'       => 'Ajouter Image Accueil',
		'edit_item'          => 'Modifier Image Accueil',
		'new_item'           => 'Nouveau',
		'all_items'          => 'liste des images',
		'view_items'         => 'Voir element',
		'search_items'       => 'Cherche une image accueil',
		'not_found'          => 'Aucun element trouve',
		'not_found_in_trash' => 'Aucun element dans la corbeille',
		'menu_name'          => 'TTE Gallery', 
		
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => true,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon'          => get_stylesheet_directory_uri() . '/images/assets/logo.png',
		'publicly_queryable' => false,
		'exclude_from_searsh'=> true,
		'supports'           => array( 'title', 'editor', 'page-attributes', 'thumbnail')
	);

	register_post_type( 'MAZ_slider', $args );
}

add_action( 'init', 'MAZ_slider_init' );

//**************** Set Up ***********




add_filter('manage_posts_columns', 'MAZ_col_change'); 

// change nom colonnes 
function MAZ_col_change($columns) { 
	$columns['MAZ_slider_image_o­rder'] = "Ordre"; 
	$columns['MAZ_slider_image'] = "Image affichée"; 
	return $columns; } 

add_action('manage_posts_custom_column', 'MAZ_content_show', 10 ,2); 


// affiche contenu 
function MAZ_content_show($column, $post_id) { 
	global $post; 
	if ( $column == 'MAZ_slider_image' ) { 
		echo the_post_thumbnail(array(80,80)); 
	} 
	if ( $column == 'MAZ_slider_image_o­rder' ) { 
		echo $post->menu_order; } 
	}
// le tri
function MAZ_change_slides_order($query) {
	
	global $post_type, $pagenow;

	if($pagenow == 'edit.php' && $post_type == 'MAZ_slider'){
		$query->query_vars['orderby'] = 'menu_order';
		$query->query_vars['order'] = 'asc';
	}
}

add_action('pre_get_posts','MAZ_change_slides_order');



//**************** Slider LaUne ***********


function SLD_slider_init() {
	$labels = array(
		'name'               => 'Sliders : Taille Image : 1366 x 799',
		'singular_name'      => 'Image  Accueil',
		'add_new'            => 'Ajouter image',
		'add_new_item'       => 'Ajouter Image Accueil',
		'edit_item'          => 'Modifier Image Accueil',
		'new_item'           => 'Nouveau',
		'all_items'          => 'liste des images',
		'view_items'         => 'Voir element',
		'search_items'       => 'Cherche une image accueil',
		'not_found'          => 'Aucun element trouve',
		'not_found_in_trash' => 'Aucun element dans la corbeille',
		'menu_name'          => 'Sliders', 
		
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => true,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'publicly_queryable' => false,
		'exclude_from_searsh'=> true,
		'supports'           => array( 'title', 'editor', 'page-attributes', 'thumbnail')
	);

	register_post_type( 'SLD_slider', $args );
}

add_action( 'init', 'SLD_slider_init' );

//**************** Set Up ***********





// change nom colonnes 



// affiche contenu 

