

<?php get_header(); ?>

	<section id="banner" class="banner">
		<div class="container">
			<div class="row">
				<div class="main_banner_area text-center">
					<div class="col-md-12 col-sm-12">
						<div class="single_banner_text wow zoomIn" data-wow-duration="1s">
						<?php the_custom_logo(); ?>
						<div class="separetor"></div>
							<h2>Nous prenons en charge</h2>  
                            <h2>le déroulement idéal de votre événement</h2>
							<h5>l’intégralité des services qui assureront</h5>
							
							
						</div>
					</div>
					
					
					<div class="scrolldown">
						<a href="#wedo" class="scroll_btn"></a>
					</div>
				</div>
				
				
			</div>
		</div>
	</section><!-- End of Banner Section -->

	<section id="wedo">
		<?php if(have_posts()): ?>
		<div class="container">
			<div class="row">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>Des solutions numériques intéressantes à intégrer à vos événements</h2>
					
					
				</div>
			<div class="wedo_content_area">

				<?php while(have_posts()): the_post(); ?>
					<?php if (in_category('solution')) : ?>
				<div class="col-md-4 ">
				<div class="single_wedo wow fadeIn text-center" data-wow-duration="1s" style="min-height: 260px;">
							
					<?php the_post_thumbnail('thumbnail'); ?>
							<div class="single_right_text text-center" >
								<h4><?php the_title(); ?></h4>
								<p style="text-align: justify;">
								<?php  the_excerpt(); ?>
								</p>
							</div>
				</div>
				</div>

				<?php endif; endwhile;  ?>
					
			</div>

			</div>
		</div>

<?php	else:
			echo 'pas de resultats';
		endif; ?>

	</section>

	<section id="featured" class="featured">
		<div class="container">
			<div class="row">
				<div class="head_title text-center wow flipInX" data-wow-duration="1s">
					<h2>ILS ONT RECOURU A NOUS</h2>
				</div>
			</div>
		</div>
		<div class="main_featured_content">
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f1.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Grand prix Marrakech</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f2.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Festival du film</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f3.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Salon du cheval</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f4.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Mawazine</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f5.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Afrique développement</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f6.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Climate chance</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f7.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Festival musique sacrée fes</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f8.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Festival d'ifrane</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">
					<img src="<?php echo get_template_directory_uri();?>/images/f9.jpg" alt="" />
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white">Halieutis</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</section>

	<div id="counterUp"></div>


	<section id="co" class="counterUp">
		<div class="counter_overlay">
			<div class="container">
				<div class="row">
					
						<div class="col-md-5 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1s">
								<h4><i class="fa fa-puzzle-piece"></i><span class="static-counter">A PROPOS DE NOUS</span></h4>
								<div class="separetorwhite"></div>
								<p class='apropos-txt'>
									<?php dynamic_sidebar( 'widgetized-texte' ); ?>
								</p>
								
							</div>
						</div>
						<div class="col-md-7 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1.8s">
								<h4><i class="fa fa-puzzle-piece"></i><span class="static-counter">Suivez nous sur YouTube</span></h4>
								<div class="separetorwhite"></div>
									<div class="embed-responsive embed-responsive-16by9">

 <!--    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/c85q-sMJnNI" allowfullscreen></iframe> --> 
 									<?php dynamic_sidebar( 'widgetized-footer-video' ); ?>


    								</div>
							</div>
						</div>
					
				</div>
			</div>
		</div>
	</section>
	

	<section>
		<div class="container-fluid">
			<div class="row text-center">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>NOS REFERENCES</h2>
				</div>
				<div class="col-sm-2 wow fadeIn" data-wow-duration="5s" >
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-1.jpg" class="rounded" alt="" />
				</div>
				<div class="col-sm-2">
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-2.jpg" class="rounded" alt="" />
				</div>
				<div class="col-sm-2">
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-3.jpg" class="rounded" alt="" />
				</div>
				<div class="col-sm-2">
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-4.jpg" class="rounded" alt="" />
				</div>
				<div class="col-sm-2">
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-5.jpg" class="rounded" alt="" />
				</div>
				<div class="col-sm-2">
					<img src="<?php echo get_template_directory_uri();?>/images/ref-logo-6.jpg" class="rounded" alt="" />
				</div>
			</div>
		</div>
	</section>

	<div class="container">
			<div class="row">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>NOS SERVICES</h2>
				</div>
			</div>
	</div>

	<section id="counterUp" class="counterUp-service">
			<div class="container">

				<div class="row">
						<div class="col-md-6 wow zoomIn" data-wow-duration="3s" style='margin-top:40px;'>
							<?php $theme_opts = get_option('MAZ_opts'); ?>
							<img src="<?php echo $theme_opts['legend_01_url']; ?>" class="img-responsive" alt="" />
							
						</div>
						
						<div class="col-md-6 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1s">
								
								<p class='apropos-txt'>
									
									<?php echo $theme_opts['legend_01']; ?>
								</p>
							
							<button type="button" class="btn btn-secondary btn-block">Contactez-nous</button>
							</div>
						</div>
						
					
				</div>
			</div>
		
	</section>




<div class="container" style="margin-top:40px; margin-bottom:40px">
	<div class="row">
	<?php dynamic_sidebar( 'widgetized-gallery-2' ); ?>
</div>
</div>





	

	<section>
		<div class="container-fluid bg-contact">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<p class="contact-txt">Vous avez une question en particulier, vous voudriez demander un devis ou tout simplement prendre conseil, n'hésitez pas à nous écrire.</p>
					</div>
					<div class="col-md-4">
						<button type="button" class="btn btn-secondary btn-block">Contactez-nous</button>
					</div>
				</div>
			</div>
		</div>
	</section>






	<section id="counterUp" class="counterUp-service">
			<div class="container">
				<div class="row wow fadeIn" data-wow-duration="3s">
						
						<?php dynamic_sidebar( 'widgetized-footer' ); ?>
						
				</div>
			</div>
		
	</section>



<?php get_footer(); ?>

