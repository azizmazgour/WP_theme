

<section id="counterUp" class="counterUp-service" style="padding:50px 0 50px 0;">
			<div class="container">
				<div class="row wow fadeIn" data-wow-duration="3s">
						
						<?php dynamic_sidebar( 'widgetized-footer' ); ?>
						
				</div>
			</div>
		
</section>

	<footer id="footer" class="footer">
		<div class="container">
			<div class="row">
				<div class="main_footer text-center wow zoomIn" data-wow-duration="1s">
						<p>Creation by  <a href="http://smarktic.com">SMARTIC</a>2017. All Rights Reserved</p>
				</div>
			</div>
		</div>
	</footer>

	<!-- STRAT SCROLL TO TOP -->
	
	<div class="scrollup">
		<a href="#"><i class="fa fa-chevron-up"></i></a>
	</div>



<?php wp_footer(); ?>
	
</body>

</html>