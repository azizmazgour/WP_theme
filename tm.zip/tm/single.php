

<?php get_header(); ?>



<section id="banner" class="banner">
		<div class="container">
			<div class="row">
				
			<img src="<?php echo get_template_directory_uri();?>/images/bannerbg-ct.jpg">	
				
				
			</div>
		</div>
	</section><!-- End of Banner Section -->




<section style="margin-top:50px; margin-bottom:50px; background:red">
	contact
</section>







	<section  class="counterUp-service">
			<div class="container">
				<div class="row wow fadeIn" data-wow-duration="3s">
						
						<?php dynamic_sidebar( 'widgetized-footer' ); ?>
						
				</div>
			</div>
		
	</section>

<?php get_footer(); ?>