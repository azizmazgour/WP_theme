

<?php get_header(); ?>

<!-- 	<section id="banner" class="banner">
		<div class="container">
			<div class="row">
				<div class="main_banner_area text-center">
					<div class="col-md-12 col-sm-12">
						<div class="single_banner_text wow zoomIn" data-wow-duration="1s">
						<?php //the_custom_logo(); ?>
						<img src="<?php //echo get_template_directory_uri();?>/images/logo2.png" alt="" />
						<div class="separetor"></div>
							<h2>Nous prenons en charge</h2>  
                            <h2>le déroulement idéal de votre événement</h2>
							<h5>l’intégralité des services qui assureront</h5>
						</div>
					</div>
					
					
					<div class="scrolldown">
						<a href="#wedo" class="scroll_btn"></a>
					</div>
				</div>
				<?php //echo get_template_directory_uri();?>/images/bannerbg.jpg
				
			</div>
		</div>
	</section>  --> 
 <?php    
		$args = array(
			'post_type' => 'SLD_slider',
			'postes_per_page' => -1,
			'orderby' => 'menu_order',
			'order' => 'ASC'
			);
		$slider_query = new WP_Query($args);

if($slider_query->have_posts()): ?>  
 
<section style="background:black;">


<div class="w3-content w3-display-container " style="max-width: none;">
<?php while ($slider_query->have_posts()): $slider_query->the_post(); ?>
<div class="w3-display-container mySlides text-center " >
 <div class="rounded img-fluid"> <?php echo the_post_thumbnail();?> </div>
  
		<div class="w3-display-middle w3-large w3-container w3-padding-16 single_banner_text wow zoomIn" data-wow-duration="1s">
						<img src="<?php echo get_template_directory_uri();?>/images/logo2.png" alt="" />
						<div class="separetor"></div>
							<h2><?php echo the_content();?></h2>  
                            
		</div>  
</div>
<?php endwhile; wp_reset_postdata();?>

<!-- 2 slide --> 

<!-- 3 slide --> 


<button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
<button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>

</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}


var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 5000); // Change image every 2 seconds
}
</script>
</script>
</section>
<?php endif; ?>



	<section id="wedo">
		<?php if(have_posts()): ?>
		<div class="container">
			<div class="row">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>Des solutions numériques intéressantes à intégrer à vos événements</h2>
					
					
				</div>
			<div class="wedo_content_area">

				<?php while(have_posts()): the_post(); ?>
					<?php if (in_category('solution')) : ?>
				<div class="col-md-4 ">
				<div class="single_wedo wow fadeIn text-center" data-wow-duration="1s" style="min-height: 260px;">
							
					<?php the_post_thumbnail('thumbnail'); ?>
							<div class="single_right_text text-center" >
								<h4><?php the_title(); ?></h4>
								<p style="text-align: justify;">
								<?php  the_excerpt(); ?>
								</p>
							</div>
				</div>
				</div>

				<?php endif; endwhile;  ?>
					
			</div>

			</div>
		</div>

<?php	else:
			echo 'pas de resultats';
		endif; ?>

	</section>
<?php    
		$args = array(
			'post_type' => 'MAZ_slider',
			'postes_per_page' => -1,
			'orderby' => 'menu_order',
			'order' => 'ASC'
			);
		$slider_query = new WP_Query($args);

if($slider_query->have_posts()): ?>

	<section id="featured" class="featured">
		<div class="container">
			<div class="row">
				<div class="head_title text-center wow flipInX" data-wow-duration="1s">
					<h2>ILS ONT RECOURU A NOUS</h2>
				</div>
			</div>
		</div>
		<div class="main_featured_content">

<?php while ($slider_query->have_posts()): $slider_query->the_post(); ?>

			<div class="col-md-4  single_featured_area">
				<div class="single_featured " data-wow-duration=".5s">


				

					<?php echo the_post_thumbnail();?>
					<div class="featured_overlay">
						<div class="overlay_content">
							<a href="" class="btn btn-white"><?php echo the_title();?></a>
						</div>
					</div>
				</div>
			</div>

<?php endwhile; wp_reset_postdata();?>

		</div>
		
	</section>

 <?php endif; ?>


	<div id="counterUp"></div>


	<section id="co" class="counterUp">
		<div class="counter_overlay">
			<div class="container">
				<div class="row">
					
						<div class="col-md-5 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1s">
								<h4><i class="fa fa-puzzle-piece"></i><span class="static-counter" style="color:#0b83c8;">A PROPOS DE NOUS</span></h4>
								<div class="separetorwhite"></div>
								<p class='apropos-txt'>
									<?php dynamic_sidebar( 'widgetized-texte' ); ?>
								</p>
								
							</div>
						</div>
						<div class="col-md-7 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1.8s">
								<h4><i class="fa fa-puzzle-piece"></i><span class="static-counter" style="color:#0b83c8;">Suivez nous sur YouTube</span></h4>
								<div class="separetorwhite"></div>
									<div class="embed-responsive embed-responsive-16by9">

 <!--    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/c85q-sMJnNI" allowfullscreen></iframe> --> 
 									<?php dynamic_sidebar( 'widgetized-footer-video' ); ?>


    								</div>
							</div>
						</div>
					
				</div>
			</div>
		</div>
	</section>
	

<section>
		<div class="container-fluid">
			<div class="row text-center">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>NOS REFERENCES</h2>
				</div>
				
				<?php if(have_posts()): ?>
				<?php while(have_posts()): the_post(); ?>
					<?php if (in_category('carousel')) : ?>
								
								<?php  the_content(); ?>
				<?php endif; endwhile;  ?>
					
			</div>

			</div>
		</div>

<?php	else:
			echo 'pas de resultats';
		endif; ?>


			</div>
		</div>
	</section>
	<div class="container" id="serviceID" style="height: 100px;">
	</div>
	<div class="container" >
			<div class="row">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>NOS SERVICES</h2>
				</div>
			</div>
	</div>

	<section id="counterUp" class="counterUp-service">
			<div class="container">

				<div class="row">
						<div class="col-md-6 wow zoomIn" data-wow-duration="3s" style='margin-top:40px;'>
							<?php $theme_opts = get_option('MAZ_opts'); ?>
							<img src="<?php echo $theme_opts['legend_01_url']; ?>" class="img-responsive" alt="" />
							
						</div>
						
						<div class="col-md-6 ">
							<div class="sinle_counter wow fadeIn" data-wow-duration="1s">
								
								<p class='apropos-txt'>
									
									<?php echo $theme_opts['legend_01']; ?>
								</p>
							
	<a href="contact" class="btn btn-secondary btn-block"  style="color:white;">Contactez-nous </a>
							</div>
						</div>
						
					
				</div>
			</div>
		
	</section>
<div class="container" id="prodID" style="height: 100px;">
</div>
<div class="container" >
			<div class="row">
				<div class="head_title text-center wow fadeIn" data-wow-duration="1.5s">
					<h2>NOS PRODUITS</h2>
				</div>
			</div>
	</div>

<div class="container" style="margin-top:40px; margin-bottom:40px">
	<div class="row">
	<?php dynamic_sidebar( 'widgetized-gallery-2' ); ?>
</div>
</div>

	<section>
		<div class="container-fluid bg-contact">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<p class="contact-txt">INSCRIPTION À LA NEWSLETTER :<br>
						 Restez informé, inscrivez-vous gratuitement à notre newsletter et recevez des nouveautés! 
						 </p>
					</div>
					<div class="col-md-4">
						
			<?php dynamic_sidebar( 'widgetized-newsletters' ); ?>
						
						
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="counterUp" class="counterUp-service">
			<div class="container">
				<div class="row wow fadeIn" data-wow-duration="3s">
						
						<?php //dynamic_sidebar( 'widgetized-footer' ); ?>
						
				</div>
			</div>
		
	</section>

	
<script type="text/javascript">
	$(document).ready(function(){
		$('#carouselExampleControls').carousel();
	});

	
</script>
	



<?php get_footer(); ?>

